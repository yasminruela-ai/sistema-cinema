from database import conectar

class FilmeRepository:

    def criar_tabela(self):
        conexao = conectar()
        cursor = conexao.cursor()

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS filmes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT,
            genero TEXT,
            duracao INTEGER
        )
        """)

        conexao.commit()
        conexao.close()

    def salvar(self, filme):
        conexao = conectar()
        cursor = conexao.cursor()

        cursor.execute("""
        INSERT INTO filmes (titulo, genero, duracao)
        VALUES (?, ?, ?)
        """, (filme.titulo, filme.genero, filme.duracao))

        conexao.commit()
        conexao.close()