from app.repository.filme_repository import FilmeRepository
from app.model.filme import Filme

class FilmeService:

    def __init__(self):
        self.repository = FilmeRepository()
        self.repository.criar_tabela()

    def cadastrar_filme(self, dados):
        filme = Filme(
            dados["titulo"],
            dados["genero"],
            dados["duracao"]
        )

        self.repository.salvar(filme)

        return {
            "mensagem": "Filme cadastrado com sucesso"
        }