from flask import Blueprint, request, jsonify
from app.service.filme_service import FilmeService

filme_bp = Blueprint("filme", __name__)

service = FilmeService()

@filme_bp.route("/filmes", methods=["POST"])
def cadastrar_filme():

    dados = request.json

    resposta = service.cadastrar_filme(dados)

    return jsonify(resposta)