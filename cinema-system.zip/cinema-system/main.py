from flask import Flask
from app.controller.filme_controller import filme_bp

app = Flask(__name__)

app.register_blueprint(filme_bp)

if __name__ == "__main__":
    app.run(debug=True)